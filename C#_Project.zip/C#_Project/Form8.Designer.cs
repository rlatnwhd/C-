﻿namespace C__Project
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Include13 = new Button();
            UnInclude13 = new Button();
            Include12 = new Button();
            UnInclude12 = new Button();
            Include11 = new Button();
            UnInclude11 = new Button();
            Include10 = new Button();
            UnInclude10 = new Button();
            Include9 = new Button();
            UnInclude9 = new Button();
            Include8 = new Button();
            UnInclude8 = new Button();
            Tax9_8 = new Button();
            Tax3_3 = new Button();
            NoTax = new Button();
            Include7 = new Button();
            UnInclude7 = new Button();
            HW = new TextBox();
            HW6 = new TextBox();
            HW5 = new TextBox();
            HW3 = new TextBox();
            HW4 = new TextBox();
            HW2 = new TextBox();
            HW1 = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // Include13
            // 
            Include13.BackColor = SystemColors.ButtonHighlight;
            Include13.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            Include13.Location = new Point(458, 1227);
            Include13.Margin = new Padding(4, 2, 4, 2);
            Include13.Name = "Include13";
            Include13.Size = new Size(150, 47);
            Include13.TabIndex = 200;
            Include13.Text = "포함";
            Include13.UseVisualStyleBackColor = false;
            // 
            // UnInclude13
            // 
            UnInclude13.BackColor = SystemColors.ButtonHighlight;
            UnInclude13.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            UnInclude13.Location = new Point(458, 1173);
            UnInclude13.Margin = new Padding(4, 2, 4, 2);
            UnInclude13.Name = "UnInclude13";
            UnInclude13.Size = new Size(150, 47);
            UnInclude13.TabIndex = 199;
            UnInclude13.Text = "미포함";
            UnInclude13.UseVisualStyleBackColor = false;
            // 
            // Include12
            // 
            Include12.BackColor = SystemColors.ButtonHighlight;
            Include12.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            Include12.Location = new Point(458, 1086);
            Include12.Margin = new Padding(4, 2, 4, 2);
            Include12.Name = "Include12";
            Include12.Size = new Size(150, 47);
            Include12.TabIndex = 198;
            Include12.Text = "포함";
            Include12.UseVisualStyleBackColor = false;
            // 
            // UnInclude12
            // 
            UnInclude12.BackColor = SystemColors.ButtonHighlight;
            UnInclude12.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            UnInclude12.Location = new Point(458, 1033);
            UnInclude12.Margin = new Padding(4, 2, 4, 2);
            UnInclude12.Name = "UnInclude12";
            UnInclude12.Size = new Size(150, 47);
            UnInclude12.TabIndex = 197;
            UnInclude12.Text = "미포함";
            UnInclude12.UseVisualStyleBackColor = false;
            // 
            // Include11
            // 
            Include11.BackColor = SystemColors.ButtonHighlight;
            Include11.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            Include11.Location = new Point(458, 941);
            Include11.Margin = new Padding(4, 2, 4, 2);
            Include11.Name = "Include11";
            Include11.Size = new Size(150, 47);
            Include11.TabIndex = 196;
            Include11.Text = "포함";
            Include11.UseVisualStyleBackColor = false;
            // 
            // UnInclude11
            // 
            UnInclude11.BackColor = SystemColors.ButtonHighlight;
            UnInclude11.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            UnInclude11.Location = new Point(458, 890);
            UnInclude11.Margin = new Padding(4, 2, 4, 2);
            UnInclude11.Name = "UnInclude11";
            UnInclude11.Size = new Size(150, 47);
            UnInclude11.TabIndex = 195;
            UnInclude11.Text = "미포함";
            UnInclude11.UseVisualStyleBackColor = false;
            // 
            // Include10
            // 
            Include10.BackColor = SystemColors.ButtonHighlight;
            Include10.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            Include10.Location = new Point(458, 789);
            Include10.Margin = new Padding(4, 2, 4, 2);
            Include10.Name = "Include10";
            Include10.Size = new Size(150, 47);
            Include10.TabIndex = 194;
            Include10.Text = "포함";
            Include10.UseVisualStyleBackColor = false;
            // 
            // UnInclude10
            // 
            UnInclude10.BackColor = SystemColors.ButtonHighlight;
            UnInclude10.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            UnInclude10.Location = new Point(458, 738);
            UnInclude10.Margin = new Padding(4, 2, 4, 2);
            UnInclude10.Name = "UnInclude10";
            UnInclude10.Size = new Size(150, 47);
            UnInclude10.TabIndex = 193;
            UnInclude10.Text = "미포함";
            UnInclude10.UseVisualStyleBackColor = false;
            // 
            // Include9
            // 
            Include9.BackColor = SystemColors.ButtonHighlight;
            Include9.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            Include9.Location = new Point(458, 644);
            Include9.Margin = new Padding(4, 2, 4, 2);
            Include9.Name = "Include9";
            Include9.Size = new Size(150, 47);
            Include9.TabIndex = 192;
            Include9.Text = "포함";
            Include9.UseVisualStyleBackColor = false;
            // 
            // UnInclude9
            // 
            UnInclude9.BackColor = SystemColors.ButtonHighlight;
            UnInclude9.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            UnInclude9.Location = new Point(458, 593);
            UnInclude9.Margin = new Padding(4, 2, 4, 2);
            UnInclude9.Name = "UnInclude9";
            UnInclude9.Size = new Size(150, 47);
            UnInclude9.TabIndex = 191;
            UnInclude9.Text = "미포함";
            UnInclude9.UseVisualStyleBackColor = false;
            // 
            // Include8
            // 
            Include8.BackColor = SystemColors.ButtonHighlight;
            Include8.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            Include8.Location = new Point(458, 503);
            Include8.Margin = new Padding(4, 2, 4, 2);
            Include8.Name = "Include8";
            Include8.Size = new Size(150, 47);
            Include8.TabIndex = 190;
            Include8.Text = "포함";
            Include8.UseVisualStyleBackColor = false;
            // 
            // UnInclude8
            // 
            UnInclude8.BackColor = SystemColors.ButtonHighlight;
            UnInclude8.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            UnInclude8.Location = new Point(458, 452);
            UnInclude8.Margin = new Padding(4, 2, 4, 2);
            UnInclude8.Name = "UnInclude8";
            UnInclude8.Size = new Size(150, 47);
            UnInclude8.TabIndex = 189;
            UnInclude8.Text = "미포함";
            UnInclude8.UseVisualStyleBackColor = false;
            // 
            // Tax9_8
            // 
            Tax9_8.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            Tax9_8.Location = new Point(512, 258);
            Tax9_8.Margin = new Padding(4, 2, 4, 2);
            Tax9_8.Name = "Tax9_8";
            Tax9_8.Size = new Size(84, 41);
            Tax9_8.TabIndex = 188;
            Tax9_8.UseVisualStyleBackColor = true;
            Tax9_8.Click += Tax9_8_Click;
            // 
            // Tax3_3
            // 
            Tax3_3.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            Tax3_3.Location = new Point(420, 258);
            Tax3_3.Margin = new Padding(4, 2, 4, 2);
            Tax3_3.Name = "Tax3_3";
            Tax3_3.Size = new Size(84, 41);
            Tax3_3.TabIndex = 187;
            Tax3_3.UseVisualStyleBackColor = true;
            Tax3_3.Click += Txt3_3_Click;
            // 
            // NoTax
            // 
            NoTax.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            NoTax.Location = new Point(326, 258);
            NoTax.Margin = new Padding(4, 2, 4, 2);
            NoTax.Name = "NoTax";
            NoTax.Size = new Size(84, 41);
            NoTax.TabIndex = 186;
            NoTax.UseVisualStyleBackColor = true;
            NoTax.Click += NoTax_Click;
            // 
            // Include7
            // 
            Include7.BackColor = SystemColors.ButtonHighlight;
            Include7.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            Include7.Location = new Point(240, 83);
            Include7.Margin = new Padding(4, 2, 4, 2);
            Include7.Name = "Include7";
            Include7.Size = new Size(102, 64);
            Include7.TabIndex = 202;
            Include7.Text = "포함";
            Include7.UseVisualStyleBackColor = false;
            Include7.Click += Include7_Click;
            // 
            // UnInclude7
            // 
            UnInclude7.BackColor = SystemColors.ButtonHighlight;
            UnInclude7.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            UnInclude7.Location = new Point(348, 83);
            UnInclude7.Margin = new Padding(4, 2, 4, 2);
            UnInclude7.Name = "UnInclude7";
            UnInclude7.Size = new Size(102, 64);
            UnInclude7.TabIndex = 201;
            UnInclude7.Text = "미포함";
            UnInclude7.UseVisualStyleBackColor = false;
            UnInclude7.Click += UnInclude7_Click;
            // 
            // HW
            // 
            HW.Font = new Font("맑은 고딕", 10.125F, FontStyle.Bold);
            HW.Location = new Point(476, 92);
            HW.Margin = new Padding(4, 2, 4, 2);
            HW.Name = "HW";
            HW.Size = new Size(146, 43);
            HW.TabIndex = 203;
            HW.TextAlign = HorizontalAlignment.Right;
            HW.TextChanged += HW_TextChanged;
            // 
            // HW6
            // 
            HW6.Font = new Font("맑은 고딕", 10.125F, FontStyle.Bold);
            HW6.Location = new Point(228, 1201);
            HW6.Margin = new Padding(4, 2, 4, 2);
            HW6.Name = "HW6";
            HW6.Size = new Size(116, 43);
            HW6.TabIndex = 209;
            HW6.TextAlign = HorizontalAlignment.Right;
            // 
            // HW5
            // 
            HW5.Font = new Font("맑은 고딕", 10.125F, FontStyle.Bold);
            HW5.Location = new Point(228, 1056);
            HW5.Margin = new Padding(4, 2, 4, 2);
            HW5.Name = "HW5";
            HW5.Size = new Size(116, 43);
            HW5.TabIndex = 208;
            HW5.TextAlign = HorizontalAlignment.Right;
            // 
            // HW3
            // 
            HW3.Font = new Font("맑은 고딕", 10.125F, FontStyle.Bold);
            HW3.Location = new Point(228, 766);
            HW3.Margin = new Padding(4, 2, 4, 2);
            HW3.Name = "HW3";
            HW3.Size = new Size(116, 43);
            HW3.TabIndex = 207;
            HW3.TextAlign = HorizontalAlignment.Right;
            // 
            // HW4
            // 
            HW4.Font = new Font("맑은 고딕", 10.125F, FontStyle.Bold);
            HW4.Location = new Point(228, 911);
            HW4.Margin = new Padding(4, 2, 4, 2);
            HW4.Name = "HW4";
            HW4.Size = new Size(116, 43);
            HW4.TabIndex = 206;
            HW4.TextAlign = HorizontalAlignment.Right;
            // 
            // HW2
            // 
            HW2.Font = new Font("맑은 고딕", 10.125F, FontStyle.Bold);
            HW2.Location = new Point(228, 619);
            HW2.Margin = new Padding(4, 2, 4, 2);
            HW2.Name = "HW2";
            HW2.Size = new Size(116, 43);
            HW2.TabIndex = 205;
            HW2.TextAlign = HorizontalAlignment.Right;
            // 
            // HW1
            // 
            HW1.Font = new Font("맑은 고딕", 10.125F, FontStyle.Bold);
            HW1.Location = new Point(228, 474);
            HW1.Margin = new Padding(4, 2, 4, 2);
            HW1.Name = "HW1";
            HW1.Size = new Size(116, 43);
            HW1.TabIndex = 204;
            HW1.TextAlign = HorizontalAlignment.Right;
            // 
            // button1
            // 
            button1.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 129);
            button1.Location = new Point(447, 1360);
            button1.Margin = new Padding(4, 2, 4, 2);
            button1.Name = "button1";
            button1.Size = new Size(244, 94);
            button1.TabIndex = 210;
            button1.Text = "급여 계산";
            button1.UseVisualStyleBackColor = true;
            button1.Click += CalculateButton_Click;
            // 
            // Form8
            // 
            AutoScaleDimensions = new SizeF(14F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImage = Properties.Resources.주_월_6주;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(755, 1495);
            Controls.Add(button1);
            Controls.Add(HW6);
            Controls.Add(HW5);
            Controls.Add(HW3);
            Controls.Add(HW4);
            Controls.Add(HW2);
            Controls.Add(HW1);
            Controls.Add(HW);
            Controls.Add(Include7);
            Controls.Add(UnInclude7);
            Controls.Add(Include13);
            Controls.Add(UnInclude13);
            Controls.Add(Include12);
            Controls.Add(UnInclude12);
            Controls.Add(Include11);
            Controls.Add(UnInclude11);
            Controls.Add(Include10);
            Controls.Add(UnInclude10);
            Controls.Add(Include9);
            Controls.Add(UnInclude9);
            Controls.Add(Include8);
            Controls.Add(UnInclude8);
            Controls.Add(Tax9_8);
            Controls.Add(Tax3_3);
            Controls.Add(NoTax);
            Margin = new Padding(4, 2, 4, 2);
            Name = "Form8";
            Text = "Form8";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Include13;
        private Button UnInclude13;
        private Button Include12;
        private Button UnInclude12;
        private Button Include11;
        private Button UnInclude11;
        private Button Include10;
        private Button UnInclude10;
        private Button Include9;
        private Button UnInclude9;
        private Button Include8;
        private Button UnInclude8;
        private Button Tax9_8;
        private Button Tax3_3;
        private Button NoTax;
        private Button Include7;
        private Button UnInclude7;
        private TextBox HW;
        private TextBox HW6;
        private TextBox HW5;
        private TextBox HW3;
        private TextBox HW4;
        private TextBox HW2;
        private TextBox HW1;
        private Button button1;
    }
}